def publish_docker():
    try:
        pass
    except Exception as e:
        raise e