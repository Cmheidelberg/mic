def publish_model_catalog():
    try:
        pass
    except Exception as e:
        raise e