RESOURCE_INPUT = "Input"
RESOURCE_OUTPUT = "Output"


class DataSpecificationCli:
    name = RESOURCE_INPUT

    def __init__(self, profile):
        self.profile = profile

