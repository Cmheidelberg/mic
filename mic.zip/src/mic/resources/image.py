RESOURCE = "Image"

class ImageCli:
    name = RESOURCE

    def __init__(self):
        pass

