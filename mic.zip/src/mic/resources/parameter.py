RESOURCE = "Parameter"


class ParameterCli:
    name = RESOURCE

    def __init__(self, profile=None):
        self.profile = profile
