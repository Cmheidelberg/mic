# -*- coding: utf-8 -*-


def test_schema_fail():
    assert True
